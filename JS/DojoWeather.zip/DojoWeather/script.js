var alert = document.querySelector(".alert")

function acceptCookies() {
    alert.remove();
}


function loadWeather(element) {
    alert("Loading weather report...");
}
