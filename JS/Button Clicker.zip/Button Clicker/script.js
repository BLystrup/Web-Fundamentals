function logout(element) {
    element.innerText = "Logout"
}

function hide (element) {
    element.remove();
}

function myFunction() {
    alert("Ninja was liked");
}